// getProjects.js
const connectToDatabase = require('./utils/mongooseClient');
const Transcription = require('./models/Transcription');
const jwt = require('jsonwebtoken');

exports.handler = async (event) => {
    try {
        // Verificar que el token JWT esté presente
        const token = event.headers.authorization?.split(' ')[1];
        if (!token) {
            return {
                statusCode: 401,
                body: JSON.stringify({ message: 'Token no proporcionado' }),
            };
        }

        let decoded;
        try {
            decoded = jwt.verify(token, process.env.JWT_SECRET);
        } catch (error) {
            return {
                statusCode: 401,
                body: JSON.stringify({ message: 'Token inválido o expirado' }),
            };
        }

        // Conectar a la base de datos
        await connectToDatabase(process.env.MONGODB_URI);

        const { projectId, transcription} = JSON.parse(event.body);

        if(!projectId){
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'projectId es requerido' }),
            };
        }
        
        const transcriptionNew = new Transcription({
            text: transcription,
            userId: decoded.id,
            projectId: projectId
        });

        return {
            statusCode: 200,
            body: JSON.stringify({ transcriptionNew }),
        };
    } catch (error) {
        console.error('Error al obtener transcripciones:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error interno del servidor' }),
        };
    }
};